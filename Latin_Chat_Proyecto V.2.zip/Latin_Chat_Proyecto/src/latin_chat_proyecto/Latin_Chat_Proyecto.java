package latin_chat_proyecto;

import Interfaces.Servidor;
import Interfaces.Logeo;

/**
 *
 * @author smit1
 */

public class Latin_Chat_Proyecto {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        Logeo.main(args);
    }
    
}
